const config = require("../../config.js")

module.exports = {
announce: {
  err: "Saale Pehle koi message to de",
  suggest: "Tum color bhi change kr skte ho by .embed <color> jesse ki RED"
},
ban: {
perms: "Mujhe Perms to de pehle badme hi ban krpaunga",
user: "User nahi diya? OK me tereko ban krta :joy:",
reason: "Reason nahi diya he user se hi mangle",
msg: "Ye bande ne koi kaand kiya hoga to ban mila he isko"
},
embed: {
  lmao: "KOi color nahi dia he de to sahi",
  msg: "Chal hogaya Iss GUild ka mene change krdia"
},
hide: {
  perms: "Saale pehle tu perms le ke aa badme ye channel hide krio",
  msg: " Yelo Done krida hide"
}





}