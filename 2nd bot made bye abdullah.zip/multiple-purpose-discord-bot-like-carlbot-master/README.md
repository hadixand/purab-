
## This Project Development is Shifted on https://github.com/dhvitOP/dyno-clone For Adding Dashboard
Create new Issue in that Project if you want Some Help in Error
## Dumb Bot Source Code
Dumb Bot is A MultiPurpose Discord Bot with 214 Commands And 85% Of Database is Based on quick.db
# Notice
For Discord.js version 13 Support go in discord.js v13 Branch Some Commands will may not work but if you got any bug or error create an issue
Removed Registering of Slash Commands Because of error
## Contact Us
https://discord.gg/FafYfmmg4Q Join Discord and My username will be Dhvit
## Features 
This bot Also Supports Many Slash-Commands
This Bot Supports :
Giveaways 
Ticket System
Music 
Reaction Roles
Custom Commands
Auto Mod
Leveling
Much More!!
# Original Bot
The Original Bot is Dumb Bot and For testing You can invite That bot from here - [Invite Bot](https://www.dumb-dsc.tk/invite)
## Support 
Tested Ones :
This Bot Project Can Run on Windows , Glitch.com, Replit.com
UnTested Ones:
Maybe Ubuntu
## Size 
This Project Size is 400mb (Counted With Database)
## Help
You can Join Our Support Server - [Support Server](https://discord.gg/fZmNMF2Cza)
## Installation
# Installing
# Self Hosting
**First of all do git clone https://github.com/dhvitOP/multiple-purpose-discord-bot-like-carlbot.git in console or Download Project from here - [Download From Here](https://github.com/dhvitOP/multiple-purpose-discord-bot-like-carlbot/archive/refs/heads/master.zip)**
# Hosting Service
**If you are using Hosting Service like Replit.com or glitch.com In there Go on New Project And in That go on Imprort From Github And Paste This - `https://github.com/dhvitOP/multiple-purpose-discord-bot-like-carlbot.git`**
# Filling Config Files
Fill the config.js and utils/gw-config.json With Your Credentials
# Config.js
```module.exports = {
    "registercommands" : false, //Write True If You Are Launching The Bot First Time
     "token": "", //Your Super Secret Bot Token
    "imageapi": "", //Your Amethyste Api You can get it from https://api.amethyste.moe/
    "ownerID": [], //Your Discord User ID
"prefix": "", //Your Bot's Prefix
"chat": {
        "url": "",
        "bid": "",
        "key": "",
        "uid": ""
    }, // You can get This Things from https://brainshop.ai
"api": "", // Your Youtube Api
"youtubeAPI": "", // Your Youtube Api
mainprefix: "",  // Again Your Prefix
"owner": "G U D B O Y", // Owner Name

  basiclang: "en", //The basic language of the bot, "fr" for French and "en" for English
    embeds: {
        color: "BLUE", //Embed color (in English)
        footers: "GIVEAWAY :tada: :tada:" //Embed footer
    },

   

    events: {
        addcolor: "GREEN", //The color of the event add (in English)
        remcolor: "RED" //The color of the event remove (in English)
    },

    reaction: "🎉", //Reaction to the giveaways if you in the console you see 'unknown emoji' that's what this emoji is not recognized by Discord

    grole: "Giveaway Manager", //If the member doesn't have permission to handle messages he can still use the giveaways commands if he has the role configured right here

    auth: {
        support: "XXX", //The link of your Discord server
        dperms: "8" //The permissions that the bot asks on we want to add it on a Discord server (8 = moderator)
    }, 
}
```
# gw-config.json
```{
    
 
    "ownerID": "720632216236851260",

    "everyoneMention": false,
    "hostedBy": true,
    "botsCanWin": false,


    "embedColor": "#000080",
    "embedColorEnd": "#FF0000",
    "reaction": "🎉",
    "giveawayEmoji": "🎉"

    
   
}
```
# Important Installation
After Downloading Project in Console Type `npm install` 
![terminal](https://user-images.githubusercontent.com/45940386/111021871-b22ee080-83e8-11eb-92cb-c2ff2ccc7b3f.png)
# Starting the Bot
After Installing The Packages in console Type `node xp.js`
![terminal](https://github.com/dhvitOP/Again-new-Backup/blob/master/image.png?raw=true)
# Result
If the Console Shows Port is running on <anything> And Logged in as < Your Bot name>
**If Your Console Shows Anything from up then Your Bot is ready and you can use it**
# Error
if It shows any error Contact us on our [Discord Server](https://discord.gg/fZmNMF2Cza)
# Slash-Commands Installation
 If you want to register your bot's Slash-commands then go on config.js and in registercommands Remove false and write true there.
    This is not tested Yet so if you get Any error in that use Gui which is made by my one of Favourites "Androz" Website - https://slash-commands-gui.netlify.app/
